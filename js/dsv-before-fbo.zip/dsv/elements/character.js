import charAnimation from '../animations/charAnimation.js';
import Element from '../element.js';
import MakeMoveableComponent from '../components/makeMoveable.js';
import { charDefinitions } from '../atlasManager.js';
import engine from '../engine.js'
import game from '../game.js'

const animationParts = charAnimation.animationParts;
const animationGroup = charAnimation.groupToParts;

const partsName = [
    'helmet', 'head', 'body', 'legs', 'face', 'capeBack',
];

function createPartData() {
    return {
        skippedFrame: 0,
        currentFrame: 0,
        skipFrame: 12,
        frames: 6,
        isNotSpriteAnimated: false,
        texOffset: [
            { x: 0 },
        ],
    };
}

class AnimationControllerComponent {
    constructor(parent) {
        this.parent = parent;

        this.partsName = partsName;
        this.parts = {}
        for (let i = 0; i < partsName.length; i++) {
            const pn = partsName[i];
            this.parts[pn] = createPartData();
        }
    }

    update() {
        partsName.forEach(x => {
            const part = this.parts[x];
            part.skippedFrame++;
            if (part.skippedFrame >= part.skipFrame) {
                part.currentFrame++;
                part.skippedFrame = 0;
            }
            if (part.currentFrame >= part.frames)
                part.currentFrame = 0;
        });
    }

    changeAnimationByGroup(groupName, animationName) {
        const animeGroups = animationGroup[groupName];
        for (let i = 0; i < animeGroups.length; i++) {
            this.changeAnimation(animeGroups[i], animationName);
        }
    }

    changeAnimation(partName, animationName) {
        const animePart = animationParts[partName];
        const anime = animePart[animationName] ?? animePart['default'];
        const part = this.parts[partName];
        if (!anime) {
            console.log(anime);
        }
        part.skipFrame = anime.skipFrame ?? 12;
        part.frames = anime.frameCount ?? anime.frames.length;
        part.isNotSpriteAnimated = anime.isNotSpriteAnimated;
        part.texOffset = [];
        for (let i = 0; i < anime.frames.length; i++) {
            const animeFrames = anime.frames[i];
            part.texOffset.push({ ...animeFrames });
            if (anime.defaultFrames) {
                if (part.texOffset[i].x != null) part.texOffset[i].x += (anime.defaultFrames.x ?? 0);
                if (part.texOffset[i].y != null) part.texOffset[i].y += (anime.defaultFrames.y ?? 0);
                if (part.texOffset[i].ax != null) part.texOffset[i].ax += (anime.defaultFrames.ax ?? 0);
                if (part.texOffset[i].ay != null) part.texOffset[i].ay += (anime.defaultFrames.ay ?? 0);
            }
        }
    }

}

export default class Character extends Element {
    constructor({ userData, position }) {
        const index = game.chars.length;
        const depth = engine.charDepth;
        super({ type: 'Character', index: index, size: { width: 32, height: 32 }, position: position, depth: depth });

        if (!userData) userData = {};
        if (!userData.username) userData.username = 'Not Defined';

        this.preset = {
            head: '/char/body/skeleton/new_head.png',
            body: '/char/body/skeleton/new_body.png',
            legs: '/char/body/skeleton/new_legs.png',
            //face: '/char/props-especial/face/moustache.png',
            capeBack: '/char/props-especial/cape/cape_back.png',
            capeFront: '/char/props-especial/cape/cape_front.png',
            helmet: '/char/props/helmet/coroa.png',
        };
        this.userData = userData;

        this.currentFrame = 0;
        this.move = new MakeMoveableComponent(this, { precision: 5 });
        this.movementSpeed = 1;
        this.animationController = new AnimationControllerComponent(this);
        this.components.push(this.move);
        this.components.push(this.animationController);

        game.chars.push(this);

        this.enable();
    }

    onEnable() {
        engine.programData['char'].addToTransform(this);

        this.animationController.changeAnimationByGroup('head', 'idle');
        this.animationController.changeAnimationByGroup('body', 'idle');
        this.animationController.changeAnimationByGroup('legs', 'idle');
        this.animationController.changeAnimationByGroup('back', 'idle');
    }

    update() {
        super.update();
        programData['char'].updateTransformPart(this, charDefinitions);
    }

    flipedX() {
        return this.movingDirection == -1;
    }

}
