import Prop from './prop.js'
import game from '../game.js'
import SimpleDraw from '../components/simpleDraw.js';

const openPortalTexture = '/portal/portal-abrindo-sheet.png';
const idlePortal = '/portal/portal-atlas.png';

export default class Portal extends Prop {
    constructor({ size, position, texture, depth }) {
        super({ type: 'Portal', size, position, texture, depth, shoudntEnable: true });

        this.components.push(new SimpleDraw(this, this.texture, (draw) => { return this.onAnimationDone(draw); }));
        this.enable();
    }

    onEnable() {
        super.onEnable();
    }

    changeTexture(texture, data) {
        super.changeTexture(texture, data);
        if (this.components[0]) this.components[0].changeTexture(texture, data);

        this.changeObjectSize({ width: this.objectSize.width * 3, height: this.objectSize.height * 3 });
    }

    onAnimationDone(draw) {
        if(this.texture == openPortalTexture) {
            if(draw.frameDirection == -1) {
                draw.stopAnimation = true;
                return true;
            }

            this.changeTexture(idlePortal);
        }
    }

    open() {
        this.changeTexture(openPortalTexture);
    }

    close() {
        this.changeTexture(openPortalTexture, { frameDirection: -1 });
    }

}