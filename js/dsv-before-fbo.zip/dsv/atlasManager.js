
const calcDepth = (def, src) => {
    return def.size - 1 - def.srcs[src].i;
}

export const atlases = {};

export const charDefinitions = {
    srcs: {},
    size: 0,
    calcDepth: (src) => { return calcDepth(charDefinitions, src); }
};

export const propsDefinition = {
    srcs: {},
    size: 0,
    calcDepth: (src) => { return calcDepth(propsDefinition, src); }
}

export const createCharSpriteAtlas = async () => {
    const heightOfImage = 32;

    const n = Date.now();
    const imgs = [];
    const loadCharImage = (src, arrs) => {
        return new Promise((resolve) => {
            const image = new Image();
            image.onload = function () {
                if (arrs.length > 1) {
                    const i = arrs[0].indexOf(arrs[1]);
                    charDefinitions.srcs[src] = { i: i == -1 ? arrs[0].length : i, o: arrs[1].length };

                    arrs[1].push(image);
                    if (arrs[1].length == 1) {
                        arrs[0].push(arrs[1]);
                        charDefinitions.size++;
                    }

                    resolve(image);
                    return;
                }

                charDefinitions.srcs[src] = { i: arrs[0].length, o: undefined };
                arrs[0].push(image);
                charDefinitions.size++;

                resolve(image);
            }
            image.src = src;
        });
    };


    const props1 = [];

    await Promise.all([
        loadCharImage('/char/body/skeleton/new_legs.png', [imgs]),
        loadCharImage('/char/body/skeleton/new_body.png', [imgs]),
        loadCharImage('/char/body/skeleton/new_head.png', [imgs]),
        loadCharImage('/char/body/skeleton/legs.png', [imgs]),
        loadCharImage('/char/body/skeleton/body.png', [imgs]),
        loadCharImage('/char/body/skeleton/head.png', [imgs]),
        loadCharImage('/char/props-especial/face/moustache.png', [imgs]),
        loadCharImage('/char/props-especial/cape/cape_front.png', [imgs]),
        loadCharImage('/char/props-especial/cape/cape_back.png', [imgs]),
        loadCharImage('/char/props/helmet/blackpower.png', [imgs, props1]),
        loadCharImage('/char/props/helmet/bruxo.png', [imgs, props1]),
        loadCharImage('/char/props/helmet/coroa.png', [imgs, props1]),
        loadCharImage('/char/props/helmet/mugi.png', [imgs, props1]),
        loadCharImage('/char/props/helmet/sjins.png', [imgs, props1]),
        loadCharImage('/char/props/helmet/ninja.png', [imgs, props1]),
    ]);

    let width = imgs[1].width + 64;
    const countOfLayers = imgs.length;

    const c = new OffscreenCanvas(width, heightOfImage * countOfLayers);
    const ctx = c.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.translate(0, c.height);
    ctx.scale(1, -1);


    const cNormal = new OffscreenCanvas(width, heightOfImage * countOfLayers);
    const ctxNormal = cNormal.getContext("2d");
    ctxNormal.imageSmoothingEnabled = false;
    ctxNormal.clearRect(0, 0, cNormal.width, cNormal.height);
    ctxNormal.translate(0, cNormal.height);
    ctxNormal.scale(1, -1);

    for (let i = 0; i < imgs.length; i++) {
        const img = imgs[i];
        if (Array.isArray(img)) {
            for (let x = 0; x < img.length; x++) {
                const image = img[x];
                ctx.drawImage(image, x * heightOfImage, i * heightOfImage);
            }
            continue;
        }
        ctx.drawImage(img, 0, i * heightOfImage);
    }

    const imageData = ctx.getImageData(0, 0, width, heightOfImage * countOfLayers).data;
    const imageDataNormal = ctxNormal.getImageData(0, 0, width, heightOfImage * countOfLayers).data;

    console.log('createCharSpriteAtlas', Date.now() - n);

    atlases['char'] = {
        canvas: c,
        ctx: ctx,
        imageHeight: heightOfImage,
        layersCount: countOfLayers,
        imgData: imageData,
        normalCanvas: cNormal,
        normalCtx: ctxNormal,
        normalImgData: imageDataNormal
    };
    return atlases['char'];
}

export const createPropsSpriteAtlas = async () => {
    const n = Date.now();

    const data = {
        maxHeight: { src: '', size: 0 },
        maxWidth: { src: '', size: 0 },
        srcs: {},
        size: 0,
    };

    const imgsNormal = {};
    const imgs = [];
    const loadPropsImage = (src, srcNormal) => {
        return new Promise((resolve) => {
            let ok = false;
            const image = new Image();
            image.onload = function () {
                if (image.width > data.maxWidth.size) {
                    data.maxWidth.src = src;
                    data.maxWidth.size = image.width;
                }
                if (image.height > data.maxHeight.size) {
                    data.maxHeight.src = src;
                    data.maxHeight.size = image.height;
                }

                data.size++;
                imgs.push(image);
                if (srcNormal && !ok) {
                    ok = true;
                    return;
                }
                resolve(image);
            }

            if (srcNormal) {
                const imageNormal = new Image();
                imageNormal.onload = function () {
                    imgsNormal[src] = imageNormal;
                    if (!ok) {
                        ok = true;
                        return;
                    }
                    resolve(image);
                }

                imageNormal.src = srcNormal;
            }

            image.src = src;
        });
    };

    const props1 = [];

    await Promise.all([
        loadPropsImage('/world/props/casa.png'),
        loadPropsImage('/world/props/bonfas.png'),
        loadPropsImage('/world/natural/arvore.png'),
        loadPropsImage('/world/natural/chao.png'),
        loadPropsImage('/world/natural/moita.png'),
        loadPropsImage('/world/natural/nuvem.png'),
        loadPropsImage('/world/props/carroca.png', '/world/props/carroca-normal.png'),
        loadPropsImage('/teste2.png', '/teste2-normalmap.png'),
        loadPropsImage('/grama.png'),
        loadPropsImage('/Background1ok1.png'),
        loadPropsImage('/Atlas_new_parado.png'),
        loadPropsImage('/Atlas_new_Braco_aberto.png'),
        loadPropsImage('/portal/portal-atlas.png'),
        loadPropsImage('/portal/portal-abrindo-sheet.png'),
    ]);

    const reordered = imgs.sort((a, b) => b.height - a.height);
    const numOfLayers = Math.ceil(reordered.map(x => x.height).reduce((a, b) => a + b) / data.maxHeight.size) + 2;

    const c = new OffscreenCanvas(data.maxWidth.size, data.maxHeight.size * numOfLayers);
    const ctx = c.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.translate(0, c.height);
    ctx.scale(1, -1);

    const cNormal = new OffscreenCanvas(data.maxWidth.size, data.maxHeight.size * numOfLayers);
    const ctxNormal = cNormal.getContext("2d");
    ctxNormal.imageSmoothingEnabled = false;
    ctxNormal.clearRect(0, 0, cNormal.width, cNormal.height);
    ctxNormal.translate(0, cNormal.height);
    ctxNormal.scale(1, -1);

    const drawSpriteAt = (img, { src, index, offset }) => {

        if (!offset.w) offset.w = 0;
        if (!offset.h) offset.h = 0;

        if (imgsNormal[src]) {
            ctxNormal.drawImage(imgsNormal[src], 0, (index * data.maxHeight.size) + offset.h);
        }

        ctx.drawImage(img, 0, (index * data.maxHeight.size) + offset.h);
        data.srcs[src] = src;
        propsDefinition.srcs[src] = {
            i: index,
            ow: offset.w,
            oh: data.maxHeight.size - (img.height + offset.h),
            w: img.width,
            h: img.height,
        };
    }

    //let offset = 0;
    let currentHeight = 0;
    let currentWidth = 0;
    for (let i = 0; i < data.size; i++) {
        const img = imgs[i];
        const src = img.src.replace(location.origin, '');
        if (data.srcs[src]) continue;

        if (currentHeight + img.height > data.maxHeight.size) {
            const heightEnabled = data.maxHeight.size - currentHeight;
            //console.log(`heightEnabled`, heightEnabled);

            const nImg = reordered.find(x => x.height <= heightEnabled && data.srcs[src] == undefined);
            if (nImg) {
                drawSpriteAt(nImg, { src: nImg.src.replace(location.origin, ''), index: propsDefinition.size, offset: { w: 0, h: currentHeight } });
            }

            currentHeight = 0;
            currentWidth = 0;
            propsDefinition.size++;
        }
        drawSpriteAt(img, { src: src, index: propsDefinition.size, offset: { w: currentWidth, h: currentHeight } });
        currentHeight += img.height;
        // currentHeight += img.height;
        // console.log({ src, i: propsDefinition.size, offset, currentHeight, imgHeight: img.height });
        // if (imgs[i + 1] && imgs[i + 1].height > data.maxHeight.size - currentHeight) {
        //     offset += data.maxHeight.size - currentHeight;
        //     currentHeight = 0;
        //     propsDefinition.size ++;
        // }

        // ctx.drawImage(img, 0, offset);
        // if(imgsNormal[src]) {
        //     //console.log(src);
        //     ctxNormal.drawImage(imgsNormal[src], 0, offset);
        // }
        // propsDefinition.srcs[src] = {
        //     i:  propsDefinition.size,
        //     ow: 0,
        //     oh: currentHeight == 0 ? 0 : data.maxHeight.size - currentHeight,
        //     w: img.width,
        //     h: img.height,
        // };
        // offset += img.height;
    }
    propsDefinition.size++;

    const imageData = ctx.getImageData(0, 0, data.maxWidth.size, data.maxHeight.size * numOfLayers).data;
    const imageDataNormal = ctxNormal.getImageData(0, 0, data.maxWidth.size, data.maxHeight.size * numOfLayers).data;

    console.log(data);
    console.log('createPropsSpriteAtlas', Date.now() - n);
    atlases['world_prop'] = {
        canvas: c,
        ctx: ctx,
        imageHeight: data.maxHeight.size,
        layersCount: numOfLayers,
        imgData: imageData,
        normalCanvas: cNormal,
        normalCtx: ctxNormal,
        normalImgData: imageDataNormal
    };
    return atlases['world_prop'];
}

export const createBackgroundAtlas = async () => {
    const n = Date.now();

    const data = {
        maxHeight: { src: '', size: 0 },
        maxWidth: { src: '', size: 0 },
        srcs: {},
        size: 0,
    };

    const imgsNormal = {};
    const imgs = [];

    const order = [

    ];
    const loadPropsImage = (src) => {
        order.push(src);
        return new Promise((resolve) => {
            let ok = false;
            const image = new Image();
            image.onload = function () {
                if (image.width > data.maxWidth.size) {
                    data.maxWidth.src = src;
                    data.maxWidth.size = image.width;
                }
                if (image.height > data.maxHeight.size) {
                    data.maxHeight.src = src;
                    data.maxHeight.size = image.height;
                }

                data.size++;
                imgs.push(image);
                resolve(image);
            }

            image.src = src;
        });
    };

    await Promise.all([
        loadPropsImage('/world/ceu/dia.png'),
        loadPropsImage('/world/ceu/tarde.png'),
        loadPropsImage('/world/ceu/noite-loop.png'),
    ]);

    const numOfLayers = data.size;

    const c = new OffscreenCanvas(data.maxWidth.size, data.maxHeight.size * numOfLayers);
    const ctx = c.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.translate(0, c.height);
    ctx.scale(1, -1);

    const cNormal = new OffscreenCanvas(data.maxWidth.size, data.maxHeight.size * numOfLayers);
    const ctxNormal = cNormal.getContext("2d");
    ctxNormal.imageSmoothingEnabled = false;
    ctxNormal.clearRect(0, 0, cNormal.width, cNormal.height);
    ctxNormal.translate(0, cNormal.height);
    ctxNormal.scale(1, -1);

    //let offset = 0;
    let currentHeight = 0;
    for (let i = 0; i < data.size; i++) {
        const img = imgs.find(x => x.src.replace(location.origin, '') == order[i]);
        ctx.drawImage(img, 0, currentHeight);
        currentHeight += img.height;
    }

    const imageData = ctx.getImageData(0, 0, data.maxWidth.size, data.maxHeight.size * numOfLayers).data;
    const imageDataNormal = ctxNormal.getImageData(0, 0, data.maxWidth.size, data.maxHeight.size * numOfLayers).data;

    console.log(data);
    console.log('createBackgroundAtlas', Date.now() - n);
    atlases['world_background'] = {
        canvas: c,
        ctx: ctx,
        imageHeight: data.maxHeight.size,
        layersCount: numOfLayers,
        imgData: imageData,
        normalCanvas: cNormal,
        normalCtx: ctxNormal,
        normalImgData: imageDataNormal
    };
    return atlases['world_background'];
}

export const createAllAtlas = async () => {
    return await Promise.all([
        createCharSpriteAtlas(),
        createPropsSpriteAtlas(),
        createBackgroundAtlas(),
    ]);
};

export default {
    atlases,
    charDefinitions,
    propsDefinition,
    createAllAtlas,
    createCharSpriteAtlas,
    createPropsSpriteAtlas,
};