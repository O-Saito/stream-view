import sprites from './shader/sprites.js';
import background from './shader/background.js';

export const canvas = document.getElementById('gameCanvas');
export const gl = canvas.getContext('webgl2', { antialias: false, preserveDrawingBuffer: false, imageSmoothingEnabled: false });

gl.enable(gl.BLEND);
gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
gl.enable(gl.DEPTH_TEST);
gl.depthFunc(gl.LEQUAL);
//gl.enable(gl.FRAMEBUFFER_SRGB);

const countOfCharProps = 7;
const charDepth = 0.80;
let on = {};
let framerate = 0;
let textureIndex = 0;
let fpsInterval = 1000 / 61;
let then = Date.now();
let now = null, elapsed = null;
export const programData = {};

export const resizeCanvas = (width, height) => {
  canvas.width = width;
  canvas.height = height;

  canvas.style.width = `${canvas.width}px`;
  canvas.style.height = `${canvas.height}px`;
  canvas.style.zoom = 1;
  canvas.style.imageRendering = 'pixelated';
  canvas.style.transform = 'scale(1)';
  canvas.style.transformOrigin = '0 0';
  canvas.style.willChange = 'transform';
  canvas.style.contain = 'strict';
  document.body.style.transform = 'translateZ(0)';
  document.body.style.willChange = 'transform';
  //document.body.style.contain = 'strict';
  document.body.style.zoom = 1;

  gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
  gl.viewport(0, 0, canvas.width, canvas.height);
}

export const setupProgram = ({ vertexSource, fragmentSource, getUniforms, getAttributes, setup, addToTransform, updateTransformPart }) => {

  const program = gl.createProgram();

  const vertexShader = gl.createShader(gl.VERTEX_SHADER);
  gl.shaderSource(vertexShader, vertexSource);
  gl.compileShader(vertexShader);
  gl.attachShader(program, vertexShader);

  if (!gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS)) {
    console.log(gl.getShaderInfoLog(vertexShader));
    throw new Error("shader not linked");
  }

  const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
  gl.shaderSource(fragmentShader, fragmentSource);
  gl.compileShader(fragmentShader);
  gl.attachShader(program, fragmentShader);

  if (!gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS)) {
    console.log(gl.getShaderInfoLog(fragmentShader));
    throw new Error("shader not linked");
  }

  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.log(gl.getShaderInfoLog(vertexShader));
    console.log(gl.getShaderInfoLog(fragmentShader));
    console.log(gl.getProgramInfoLog(program));
    throw new Error("Program not linked");
  }

  const locals = {
    u: getUniforms ? getUniforms(program) : {},
    a: getAttributes ? getAttributes(program) : {}
  };

  return {
    program: program,
    vertexShader: vertexShader,
    fragmentShader: fragmentShader,
    locals: locals,
    addToTransform,
    updateTransformPart
  }
};

export const vertexAttribPointer = (pointers) => {
  const byteCount = pointers.reduce((partialSum, x) => partialSum + (x.size * 4), 0);;
  let byteOffset = 0;
  for (let i = 0; i < pointers.length; i++) {
    const pointer = pointers[i];
    gl.vertexAttribPointer(pointer.local, pointer.size, pointer.type, pointer.normalized, byteCount, byteOffset);
    byteOffset += pointer.size * 4;
  }
};

export const createTexture = (gl, type) => {
  const index = textureIndex;
  const texture = gl.createTexture();
  gl.activeTexture(gl.TEXTURE0 + index);
  gl.bindTexture(type, texture);
  textureIndex++;
  return [texture, index];
}

export const submit2DArrayImage = ({ gl, width, height, imageHeight, layerCount, imgData }) => {

  gl.texStorage3D(gl.TEXTURE_2D_ARRAY, 1, gl.RGBA8, width, imageHeight, layerCount);
  const pbo = gl.createBuffer();
  gl.bindBuffer(gl.PIXEL_UNPACK_BUFFER, pbo);
  gl.bufferData(gl.PIXEL_UNPACK_BUFFER, imgData, gl.STATIC_DRAW);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.pixelStorei(gl.UNPACK_ROW_LENGTH, width);
  gl.pixelStorei(gl.UNPACK_IMAGE_HEIGHT, height);

  for (let i = 0; i < layerCount; i++) {
    const row = i * imageHeight;
    // Assign that origin point to the PBO
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.pixelStorei(gl.UNPACK_SKIP_PIXELS, 0);
    gl.pixelStorei(gl.UNPACK_SKIP_ROWS, row);
    // Tell webgl to use the PBO and write that texture at its own depth
    gl.texSubImage3D(gl.TEXTURE_2D_ARRAY, 0, 0, 0, i, width, imageHeight, 1, gl.RGBA, gl.UNSIGNED_BYTE, 0);
  }

  gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

  return pbo;
}

programData['char'] = setupProgram({
  vertexSource: sprites.vertexShaderSource,
  fragmentSource: sprites.fragmentShaderSource,
  setup: (program, locals) => {
  },
  getUniforms: (p) => { return sprites.getUniforms(gl, p); },
  getAttributes: (p) => { return sprites.getAttributes(gl, p); },
  addToTransform: (o) => {
    const pd = programData['char'];
    gl.useProgram(pd.program);
    gl.bindVertexArray(pd.vao1);
    //gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bindBuffer(gl.ARRAY_BUFFER, pd.transformBuffer);
    // gl.drawArrays(gl.POINTS, 0, 4);

    pd.transformData = new Float32Array([
      ...pd.transformData,
      1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 0, 0, 1, 1,
    ]);
    gl.bufferData(gl.ARRAY_BUFFER, pd.transformData, gl.DYNAMIC_DRAW);
    gl.bindVertexArray(null);
  },
  updateTransformPart: (char, charDefinitions) => {
    const dataLength = 10;
    const dataSize = dataLength * countOfCharProps;
    const pd = programData['char'];

    let d = char.depth;
    let skip = 0;
    const setData = (i, type) => {
      i = i + skip;
      const pos = { x: char.position.x, y: char.position.y };
      const texCoordOffset = { x: 0, y: 0 };
      let animationLayer = char.preset[type] == undefined ? 0 : charDefinitions.calcDepth(char.preset[type]);

      if (char.preset[type] == undefined) {
        texCoordOffset.x = -char.size.width;
        texCoordOffset.y = -char.size.height;
      }

      if (char.animationController.partsName.find(x => x == type)) {
        const part = char.animationController.parts[type];
        const texOffset = part.currentFrame >= part.texOffset.length ? part.texOffset[0] : part.texOffset[part.currentFrame];
        if (texCoordOffset.x != -char.size.width) {
          texCoordOffset.x = ((part.isNotSpriteAnimated ? 0 : part.currentFrame) * char.size.width) + (texOffset?.x ?? 0) + (char.size.width * (charDefinitions.srcs[char.preset[type]]?.o ?? 0));
        }
        if (texOffset?.ax) pos.x += texOffset?.ax;
        if (texOffset?.ay) pos.y += texOffset?.ay;
      } else {
        if (char.currentFrame != undefined && char.currentFrame != null) {
          texCoordOffset.x = (char.currentFrame ?? 0) * char.size.width;
        }
      }
      pd.transformData[i + 0] = pos.x;
      pd.transformData[i + 1] = pos.y;
      pd.transformData[i + 2] = texCoordOffset.x;
      pd.transformData[i + 3] = texCoordOffset.y;
      pd.transformData[i + 4] = animationLayer;
      pd.transformData[i + 5] = d;
      pd.transformData[i + 6] = char.flipedX() ? char.size.width : 0;
      pd.transformData[i + 7] = 0;
      pd.transformData[i + 8] = char.size.width;
      pd.transformData[i + 9] = char.size.height;
      d -= 0.0001;
      skip += dataLength;
    }

    setData(char.index * dataSize, 'capeBack');
    setData(char.index * dataSize, 'legs');
    setData(char.index * dataSize, 'body');
    setData(char.index * dataSize, 'capeFront');
    setData(char.index * dataSize, 'head');
    setData(char.index * dataSize, 'face');
    setData(char.index * dataSize, 'helmet');
  }
});

programData['prop'] = setupProgram({
  vertexSource: sprites.vertexShaderSource,
  fragmentSource: sprites.fragmentShaderSource,
  setup: (program, locals) => {
  },
  getUniforms: (p) => { return sprites.getUniforms(gl, p); },
  getAttributes: (p) => { return sprites.getAttributes(gl, p); },
  addToTransform: (p) => {// (url, { pos, size }) => {
    const prop = propsDefinition.srcs[p.texture];

    const pos = { x: p.position.x, y: p.position.y };
    const size = { w: p.size.width, h: p.size.height };
    pos.w = size.w;
    pos.h = size.h;
    pos.xw = pos.x + pos.w;
    pos.yh = pos.y + pos.h;

    const pd = programData['prop'];
    gl.useProgram(pd.program);
    gl.bindVertexArray(pd.vao1);
    gl.bindBuffer(gl.ARRAY_BUFFER, pd.transformBuffer);

    const tc = {
      x: 0, y: 0,
      w: size.w, h: size.h,
    }
    tc.xw = tc.x + tc.w;
    tc.yh = tc.y + tc.h;

    const imageLayer = propsDefinition.calcDepth(p.texture);
    pd.transformData = new Float32Array([
      ...pd.transformData,
      0, 0, tc.x, tc.y, pos.x, pos.y, prop.ow, prop.oh, imageLayer, 1, 0, 0, 1, 1,
      pos.w, 0, tc.xw, tc.y, pos.x, pos.y, prop.ow, prop.oh, imageLayer, 1, 0, 0, 1, 1,
      0, pos.h, tc.x, tc.yh, pos.x, pos.y, prop.ow, prop.oh, imageLayer, 1, 0, 0, 1, 1,
      pos.w, 0, tc.xw, tc.y, pos.x, pos.y, prop.ow, prop.oh, imageLayer, 1, 0, 0, 1, 1,
      pos.w, pos.h, tc.xw, tc.yh, pos.x, pos.y, prop.ow, prop.oh, imageLayer, 1, 0, 0, 1, 1,
      0, pos.h, tc.x, tc.yh, pos.x, pos.y, prop.ow, prop.oh, imageLayer, 1, 0, 0, 1, 1,
    ]);
    gl.bufferData(gl.ARRAY_BUFFER, pd.transformData, gl.DYNAMIC_DRAW);
    gl.bindVertexArray(null);

  },
  updateTransformPart: (prop) => {
    const pd = programData['prop'];
    let d = 1;

    let skip = 4;
    let attrib = 10;
    let vertex = 6;
    let i = prop.index * ((skip + attrib) * vertex);
    const pos = { x: prop.position.x, y: prop.position.y };
    const texCoordOffset = { x: prop.texCoordOffset.x, y: prop.texCoordOffset.y };
    let animationLayer = propsDefinition.calcDepth(prop.texture);

    for (let z = 0; z < vertex; z++) {
      const atual = i + (z * (skip + attrib)) + skip;

      pd.transformData[atual - 4] = prop.vertexPositions[z * skip + 0];
      pd.transformData[atual - 3] = prop.vertexPositions[z * skip + 1];
      pd.transformData[atual - 2] = prop.vertexPositions[z * skip + 2];
      pd.transformData[atual - 1] = prop.vertexPositions[z * skip + 3];

      pd.transformData[atual + 0] = pos.x;
      pd.transformData[atual + 1] = pos.y;
      pd.transformData[atual + 2] = texCoordOffset.x + ((prop.currentFrame ?? 0) * prop.size.width);
      pd.transformData[atual + 3] = texCoordOffset.y;
      pd.transformData[atual + 4] = animationLayer;
      pd.transformData[atual + 5] = prop.depth;
      pd.transformData[atual + 6] = 0;//prop.size.width;
      pd.transformData[atual + 7] = 0;//prop.size.height;
      pd.transformData[atual + 8] = prop.size.width;
      pd.transformData[atual + 9] = prop.size.height;
    }
    d -= 0.0001;
  }
});

programData['background'] = setupProgram({
  vertexSource: background.vertexShaderSource,
  fragmentSource: background.fragmentShaderSource,
  setup: (program, locals) => {
  },
  getUniforms: (p) => { return background.getUniforms(gl, p); },
  getAttributes: (p) => { return background.getAttributes(gl, p); }
});

function everySecond() {
  if (on['everySecond']) {
    for (let i = 0; i < on['everySecond'].length; i++) {
      on['everySecond'][i]();
    }
  }
  framerate = 0;
}

function everyFrame() {
  now = Date.now();
  elapsed = now - then;
  if (elapsed > fpsInterval) {
    then = now - (elapsed % fpsInterval);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    if (on['everyFrame']) {
      for (let i = 0; i < on['everyFrame'].length; i++) {
        on['everyFrame'][i]();
      }
    }
    framerate++;
  }
  requestAnimationFrame(everyFrame);
}

setInterval(everySecond, 1000);
everyFrame();

export default {
  setupProgram,
  resizeCanvas,
  vertexAttribPointer,
  createTexture,
  submit2DArrayImage,
  on: (action, func) => { if (!on[action]) on[action] = []; on[action].push(func); },
  getFramerate: () => framerate,
  charDepth,
  programData,
  canvas,
  gl,
  countOfCharProps,
};
