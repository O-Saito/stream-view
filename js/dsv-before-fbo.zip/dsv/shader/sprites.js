
const vertexShaderSource = `#version 300 es
#define GLSL_FORCE_HIGHP 1
precision mediump float;

uniform vec2 uResolution;
uniform vec2 uTextureSize;

in vec2 aPosition;
in vec2 aTexCoord;
in vec2 aPositionOffset;
in vec2 aFrameOffset;
in float aAnimationLayer;
in float aDepth;
in vec2 aFlipImage;
in vec2 aSpriteSize;

out vec2 vResolution;
out float vAnimationLayer;
out vec2 vTexCoord;
out vec2 vFlipImage;
out vec2 vTextureSize;

const float ROTATION_ANGLE = 0.0; 
mat2 rotationMatrix(float angle) {
    float s = sin(angle);
    float c = cos(angle);
    return mat2(c, -s, s, c);
}

vec2 snap_to_pixel(vec2 pos, vec2 res) {
    return floor(pos * res + 0.5) / res;
}

vec2 apply_rotation(vec2 pos, vec2 center, float angle) {
    mat2 rot = mat2(cos(angle), -sin(angle), sin(angle), cos(angle));
    vec2 rotated = rot * (pos - center) + center;
    return floor(rotated + 0.5); // Garante alinhamento com a grade
}

vec2 pixel_to_shader_pos(vec2 pixels, vec2 res) {
    float aspectRatio = res.x / res.y;
    vec2 zeroToOne = pixels / res;
    vec2 zeroToTwo = zeroToOne * 2.0;
    vec2 clipSpace = zeroToTwo - 1.0;
    return clipSpace;
}

void main()
{   
    vec2 spriteCenter = aSpriteSize * 0.5;

    vec2 localPos = aPosition - spriteCenter;
    vec2 rotatedPos = apply_rotation(localPos, vec2(0.0), ROTATION_ANGLE);
    vec2 finalPos = rotatedPos + spriteCenter + aPositionOffset;
    vec2 snappedPos = snap_to_pixel(finalPos, uResolution);
    vec2 correctPos = pixel_to_shader_pos(snappedPos, uResolution);
    vec2 correctTexCoord = (aTexCoord + aFrameOffset) / uTextureSize;

    // OLD
    // vec2 correctOffset = (aPositionOffset/ uResolution) * 2.0;
    // vec2 correctPos = pixel_to_shader_pos(aPosition, uResolution);
    // vec2 correctTexCoord = (aTexCoord + aFrameOffset) / uTextureSize;
    // gl_Position = vec4(correctPos + correctOffset, aDepth, 1.0);
    // OLD

    if(aFlipImage.x > 0.0) {
        correctTexCoord.x = (aSpriteSize.x - aTexCoord.x) / uTextureSize.x;
        correctTexCoord.x += aFrameOffset.x / uTextureSize.x;
    }
    if(aFlipImage.y > 0.0) {
        correctTexCoord.y = (aSpriteSize.y - aTexCoord.y) / uTextureSize.y;
        correctTexCoord.y += aFrameOffset.y / uTextureSize.y;
    }

    vAnimationLayer = aAnimationLayer;
    vTexCoord = correctTexCoord;
    vFlipImage = aFlipImage;
    vResolution = uResolution;
    vTextureSize = uTextureSize;

    gl_Position = vec4(correctPos, aDepth, 1.0);
}`;

const fragmentShaderSource = `#version 300 es
precision mediump float;
precision mediump sampler2DArray;

const int MAX_LIGHTS = 1;

uniform sampler2DArray uAtlas;
uniform sampler2DArray uNormalAtlas;

uniform vec3 uGlobalLightPosition;
uniform vec3 uLightPosition[MAX_LIGHTS];
uniform vec3 uLightColor[MAX_LIGHTS];

uniform vec4 abcr;

in vec2 vFlipImage;
in float vAnimationLayer;
in vec2 vTexCoord;
in vec2 vResolution;
in vec2 vTextureSize;
out vec4 fragColor;

void main()
{
    float minLight = 0.4;

    vec4 tex = texture(uAtlas, vec3(vTexCoord, vAnimationLayer));
    vec4 texNormal = texture(uNormalAtlas, vec3(vTexCoord, vAnimationLayer));
    if(tex.a == 0.0) {
        discard;
    }

    vec3 normal = normalize(vec3(0.1, 0.1, 0.9));
    float brightness = 0.0;

    if(texNormal.a > 0.0){
        normal = normalize(texNormal.rgb * 2.0 - 1.0);
        if(vFlipImage.x > 0.0) normal.r *= -1.0;
        if(vFlipImage.y > 0.0) normal.g *= -1.0;
    }

    brightness = max(dot(uGlobalLightPosition, normal), 0.0);
    vec3 finalColor = tex.rgb * mix(minLight, 1.0, brightness);
    vec3 normalizedCoord = vec3((gl_FragCoord.xy / vResolution) * 2.0 - 1.0, gl_FragCoord.z);
    float aspectRatio = vResolution.x / vResolution.y;
    normalizedCoord.x *= aspectRatio;

    // Itera sobre todas as luzes
    for (int i = 0; i < MAX_LIGHTS; i++) {
        vec3 color = uLightColor[i];
        vec3 lp = vec3((uLightPosition[i].xy / vResolution) * 2.0 - 1.0, uLightPosition[i].z);
        lp.x *= aspectRatio;

        vec3 offset = lp - normalizedCoord;
        vec3 dir = normalize(offset);
        float distance = length(offset);

        float a = abcr.x;
        float b = abcr.y;
        float c = abcr.z;
        float r = abcr.w;

        float diffuse = max(0.0, dot(normal, dir));
        float attenuation = 1.0 / (distance * distance);
        //float attenuation = 1.0 / (a * distance * distance + b * distance + c);
        // float attenuation = 1.0 / ( 
        //                              (2.0 / (r * r)) * (
        //                                                    1.0 - (distance / sqrt(distance * distance + r * r))
        //                                                )
        //                           );

        // float d1 =length(normalize(lp.x - vPosition.x));
        // float d2 =length(normalize(lp.y - vPosition.y));
        // float d3 =length(normalize(lp.z - vPosition.z));
        // float attenuationX = 1.0 / (d1 * d1);
        // float attenuationY = 1.0 / (d2 * d2);
        // float attenuationZ = 1.0 / (d3 * d3);
        finalColor += color * diffuse * attenuation; //vec3(attenuationX, attenuationY, attenuationZ);
    }

    fragColor = vec4(finalColor, 1.0);
}`;

const getUniforms = (gl, p) => {
    return {
        resolution: gl.getUniformLocation(p, "uResolution"),
        textureSize: gl.getUniformLocation(p, 'uTextureSize'),
        atlas: gl.getUniformLocation(p, 'uAtlas'),
        normalAtlas: gl.getUniformLocation(p, 'uNormalAtlas'),
        globalLightPosition: gl.getUniformLocation(p, 'uGlobalLightPosition'),
        lightPosition: gl.getUniformLocation(p, 'uLightPosition'),
        lightColor: gl.getUniformLocation(p, 'uLightColor'),
        abcr: gl.getUniformLocation(p, 'abcr'),
    };
};

const getAttributes = (gl, p) => {
    return {
        position: gl.getAttribLocation(p, "aPosition"),
        positionOffset: gl.getAttribLocation(p, "aPositionOffset"),
        texCoord: gl.getAttribLocation(p, "aTexCoord"),
        frameOffset: gl.getAttribLocation(p, "aFrameOffset"),
        animationLayer: gl.getAttribLocation(p, "aAnimationLayer"),
        depth: gl.getAttribLocation(p, "aDepth"),
        flipImage: gl.getAttribLocation(p, 'aFlipImage'),
        spriteSize: gl.getAttribLocation(p, 'aSpriteSize'),
    }
};

export default {
    vertexShaderSource,
    fragmentShaderSource,
    getUniforms,
    getAttributes,
};
