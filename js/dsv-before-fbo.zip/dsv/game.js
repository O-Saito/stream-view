import engine from './engine.js';

const chars = [];
const props = [];

function updateEveryMinute() {
    
}

engine.on('everyFrame', () => {
    for (let i = 0; i < chars.length; i++) {
        const char = chars[i];
        char.index = i;
        if(!char.isEnable) continue;
        char.update();
    }
    for (let i = 0; i < props.length; i++) {
        const prop = props[i];
        prop.index = i;
        if(!prop.isEnable) continue;
        prop.update();
    }
});

export default {
    chars,
    props,
    setup: async () => {

    }
};
